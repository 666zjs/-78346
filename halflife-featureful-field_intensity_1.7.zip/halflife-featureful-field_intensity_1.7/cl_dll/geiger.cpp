/***
*
*	Copyright (c) 1996-2002, Valve LLC. All rights reserved.
*	
*	This product contains software technology licensed from Id 
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc. 
*	All Rights Reserved.
*
*   Use, distribution, and modification of this source code and/or resulting
*   object code is restricted to non-commercial enhancements to products from
*   Valve LLC.  All other use, distribution, or modification is prohibited
*   without written permission from Valve LLC.
*
****/
//
// Geiger.cpp
//
// implementation of CHudAmmo class
//

#include "hud.h"
#include "cl_util.h"
#include <ctime>

#include "parsemsg.h"
#include "event_api.h"
#include "mod_features.h"
#include "soundscripts.h"
#include "view.h"
#include "util_shared.h"

DECLARE_MESSAGE( m_Geiger, Geiger )

int CHudGeiger::Init()
{
	HOOK_MESSAGE( Geiger );

	m_iGeigerRange = 0;
	m_iFlags = 0;

	gHUD.AddHudElem( this );

	srand( (unsigned)time( NULL ) );

	return 1;
}

int CHudGeiger::VidInit()
{
	return 1;
}

int CHudGeiger::MsgFunc_Geiger( const char *pszName,  int iSize, void *pbuf )
{

	BEGIN_READ( pbuf, iSize );

	// update geiger data
	m_iGeigerRange = READ_BYTE();
	m_iGeigerRange = m_iGeigerRange << 2;

	m_iFlags |= HUD_ACTIVE;

	return 1;
}

int CHudGeiger::Draw( float flTime )
{
	return 1;
}

void CHudGeiger::Think()
{
	if (g_Paused)
		return;

	int pct;
	float flvol = 0.0f;
	bool partialSounds = false;

	if( m_iGeigerRange < 1000 && m_iGeigerRange > 0 )
	{
		// peicewise linear is better than continuous formula for this
		if( m_iGeigerRange > 800 )
		{
			pct = 0;	//Con_Printf( "range > 800\n" );
		}
		else if( m_iGeigerRange > 600 )
		{
			pct = 2;
			flvol = 0.4f;	//Con_Printf( "range > 600\n" );
			partialSounds = true;
		}
		else if( m_iGeigerRange > 500 )
		{
			pct = 4;
			flvol = 0.5f;	//Con_Printf( "range > 500\n" );
			partialSounds = true;
		}
		else if( m_iGeigerRange > 400 )
		{
			pct = 8;
			flvol = 0.6f;	//Con_Printf( "range > 400\n" );
		}
		else if( m_iGeigerRange > 300 )
		{
			pct = 8;
			flvol = 0.7f;	//Con_Printf( "range > 300\n" );
		}
		else if( m_iGeigerRange > 200 )
		{
			pct = 28;
			flvol = 0.78f;	//Con_Printf( "range > 200\n" );
		}
		else if( m_iGeigerRange > 150 )
		{
			pct = 40;
			flvol = 0.80f;	//Con_Printf( "range > 150\n" );
		}
		else if( m_iGeigerRange > 100 )
		{
			pct = 60;
			flvol = 0.85;	//Con_Printf( "range > 100\n" );
		}
		else if( m_iGeigerRange > 75 )
		{
			pct = 80;
			flvol = 0.9f;	//Con_Printf( "range > 75\n" );
			//gflGeigerDelay = cl.time + GEIGERDELAY * 0.75;
		}
		else if( m_iGeigerRange > 50 )
		{
			pct = 90;
			flvol = 0.95f;	//Con_Printf( "range > 50\n" );
			partialSounds = true;
		}
		else
		{
			pct = 95;
			flvol = 1.0f;	//Con_Printf( "range < 50\n" );
			partialSounds = true;
		}

		if( ( rand() & 127 ) < pct || ( rand() & 127 ) < pct )
		{
			const SoundScript* soundScript = g_SoundScriptSystem.GetSoundScript("Player.Geiger");
			if (soundScript && !soundScript->waves.empty())
			{
				const char* sample = nullptr;
				if (partialSounds && soundScript->waves.size() > 2)
				{
					sample = soundScript->waves[rand() % (soundScript->waves.size()/2+1)];
				}
				else if (soundScript->waves.size() > 1)
				{
					sample = soundScript->waves[rand() % soundScript->waves.size()];
				}
				else
				{
					sample = soundScript->waves[0];
				}

				flvol = RandomizeNumberFromRange(soundScript->volume) * flvol;

#if FEATURE_GEIGER_SOUNDS_FIX
				Vector view_ofs;
				cl_entity_t *pthisplayer = gEngfuncs.GetLocalPlayer();
				gEngfuncs.pEventAPI->EV_LocalPlayerViewheight( view_ofs );
				gEngfuncs.pEventAPI->EV_PlaySound( pthisplayer->index, pthisplayer->origin + view_ofs, CHAN_STATIC, sample, flvol, soundScript->attenuation, 0, RandomizeNumberFromRange(soundScript->pitch) );
#else
				PlaySound( sample, flvol );
#endif
			}
		}
	}
}
