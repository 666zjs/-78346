/***
*
*	Copyright (c) 1996-2002, Valve LLC. All rights reserved.
*	
*	This product contains software technology licensed from Id 
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc. 
*	All Rights Reserved.
*
*   Use, distribution, and modification of this source code and/or resulting
*   object code is restricted to non-commercial enhancements to products from
*   Valve LLC.  All other use, distribution, or modification is prohibited
*   without written permission from Valve LLC.
*
****/
#pragma once
#if !defined(STUDIO_EVENT_H)
#define STUDIO_EVENT_H

typedef struct mstudioevent_s
{
	int 		frame;
	int		event;
	int		type;
	char		options[64];
} mstudioevent_t;

#endif//STUDIO_EVENT_H
