/***
*
*	Copyright (c) 1996-2002, Valve LLC. All rights reserved.
*	
*	This product contains software technology licensed from Id 
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc. 
*	All Rights Reserved.
*
*   Use, distribution, and modification of this source code and/or resulting
*   object code is restricted to non-commercial enhancements to products from
*   Valve LLC.  All other use, distribution, or modification is prohibited
*   without written permission from Valve LLC.
*
****/

#include	"extdll.h"
#include	"util.h"
#include	"cbase.h"
#include	"monsters.h"
#include	"soundent.h"
#include	"graphic_debug.h"
#include	"clamp.h"
#include	"lerp.h"

LINK_ENTITY_TO_CLASS( soundent, CSoundEnt )

extern cvar_t displaysoundlist;
CSoundEnt *pSoundEnt;

const std::pair<int, const char*> g_SoundNames[] = {
	{bits_SOUND_COMBAT, "Combat"},
	{bits_SOUND_WORLD, "World"},
	{bits_SOUND_PLAYER, "Player"},
	{bits_SOUND_CARCASS, "Carcass"},
	{bits_SOUND_MEAT, "Meat"},
	{bits_SOUND_DANGER, "Danger"},
	{bits_SOUND_GARBAGE, "Garbage"},
};

//=========================================================
// CSound - Clear - zeros all fields for a sound
//=========================================================
void CSound::Clear()
{
	m_vecOrigin = g_vecZero;
	m_iType = 0;
	m_iVolume = 0;
	m_flExpireTime = 0;
	m_iNext = SOUNDLIST_EMPTY;
	m_iNextAudible = 0;
}

//=========================================================
// Reset - clears the volume, origin, and type for a sound,
// but doesn't expire or unlink it. 
//=========================================================
void CSound::Reset()
{
	m_vecOrigin = g_vecZero;
	m_iType = 0;
	m_iVolume = 0;
	m_iNext = SOUNDLIST_EMPTY;
}

//=========================================================
// FIsSound - returns true if the sound is an Audible sound
//=========================================================
bool CSound::FIsSound()
{
	if( m_iType & ( bits_SOUND_COMBAT | bits_SOUND_WORLD | bits_SOUND_PLAYER | bits_SOUND_DANGER ) )
	{
		return true;
	}

	return false;
}

//=========================================================
// FIsScent - returns true if the sound is actually a scent
//=========================================================
bool CSound::FIsScent()
{
	if( m_iType & ( bits_SOUND_CARCASS | bits_SOUND_MEAT | bits_SOUND_GARBAGE ) )
	{
		return true;
	}

	return false;
}

//=========================================================
// Spawn 
//=========================================================
void CSoundEnt::Spawn()
{
	pev->solid = SOLID_NOT;
	Initialize();

	pev->nextthink = gpGlobals->time + 1.0f;
}

//=========================================================
// Think - at interval, the entire active sound list is checked
// for sounds that have ExpireTimes less than or equal
// to the current world time, and these sounds are deallocated.
//=========================================================
void CSoundEnt::Think()
{
	int iSound;
	int iPreviousSound;

	pev->nextthink = gpGlobals->time + 0.3f;// how often to check the sound list.

	iPreviousSound = SOUNDLIST_EMPTY;
	iSound = m_iActiveSound; 

	while( iSound != SOUNDLIST_EMPTY )
	{
		if( m_SoundPool[ iSound ].m_flExpireTime <= gpGlobals->time && m_SoundPool[ iSound ].m_flExpireTime != SOUND_NEVER_EXPIRE )
		{
			int iNext = m_SoundPool[ iSound ].m_iNext;

			if (displaysoundlist.value >= 1)
			{
				ALERT(at_console, "The %s of volume %d at (%g, %g, %g) has expired. Type: ",
					m_SoundPool[iSound].FIsScent() ? "scent" : "sound",
					m_SoundPool[iSound].m_iVolume,
					m_SoundPool[iSound].m_vecOrigin.x, m_SoundPool[iSound].m_vecOrigin.y, m_SoundPool[iSound].m_vecOrigin.z);

				for (const auto& sound : g_SoundNames)
				{
					if (FBitSet(m_SoundPool[iSound].m_iType, sound.first))
					{
						ALERT(at_console, "%s; ", sound.second);
					}
				}
				ALERT(at_console, "\n");
			}

			// move this sound back into the free list
			FreeSound( iSound, iPreviousSound );

			iSound = iNext;
		}
		else
		{
			iPreviousSound = iSound;
			iSound = m_SoundPool[ iSound ].m_iNext;
		}
	}

	ReportUpdate();
}

//=========================================================
// Precache - dummy function
//=========================================================
void CSoundEnt::Precache()
{
}

//=========================================================
// FreeSound - clears the passed active sound and moves it 
// to the top of the free list. TAKE CARE to only call this
// function for sounds in the Active list!!
//=========================================================
void CSoundEnt::FreeSound( int iSound, int iPrevious )
{
	if( !pSoundEnt )
	{
		// no sound ent!
		return;
	}

	if( iPrevious != SOUNDLIST_EMPTY )
	{
		// iSound is not the head of the active list, so
		// must fix the index for the Previous sound
		//pSoundEnt->m_SoundPool[iPrevious].m_iNext = m_SoundPool[iSound].m_iNext;
		pSoundEnt->m_SoundPool[iPrevious].m_iNext = pSoundEnt->m_SoundPool[iSound].m_iNext;
	}
	else 
	{
		// the sound we're freeing IS the head of the active list.
		pSoundEnt->m_iActiveSound = pSoundEnt->m_SoundPool[iSound].m_iNext;
	}

	// make iSound the head of the Free list.
	pSoundEnt->m_SoundPool[iSound].m_iNext = pSoundEnt->m_iFreeSound;
	pSoundEnt->m_iFreeSound = iSound;
}

//=========================================================
// IAllocSound - moves a sound from the Free list to the 
// Active list returns the index of the alloc'd sound
//=========================================================
int CSoundEnt::IAllocSound()
{
	int iNewSound;

	if( m_iFreeSound == SOUNDLIST_EMPTY )
	{
		// no free sound!
		//ALERT( at_console, "Free Sound List is full!\n" );
		return SOUNDLIST_EMPTY;
	}

	// there is at least one sound available, so move it to the
	// Active sound list, and return its SoundPool index.

	iNewSound = m_iFreeSound;// copy the index of the next free sound

	m_iFreeSound = m_SoundPool[m_iFreeSound].m_iNext;// move the index down into the free list. 

	m_SoundPool[iNewSound].m_iNext = m_iActiveSound;// point the new sound at the top of the active list.

	m_iActiveSound = iNewSound;// now make the new sound the top of the active list. You're done.

	return iNewSound;
}

//=========================================================
// InsertSound - Allocates a free sound and fills it with 
// sound info.
//=========================================================
void CSoundEnt::InsertSound( CBaseEntity* pInitiator, int iType, const Vector &vecOrigin, int iVolume, float flDuration )
{
	if( !pSoundEnt )
	{
		// no sound ent!
		return;
	}

	int iThisSound = pSoundEnt->IAllocSound();

	if (iThisSound == SOUNDLIST_EMPTY)
	{
		ALERT(at_warning, "Could not AllocSound() for InsertSound() (DLL)\n");

		int iSound = pSoundEnt->m_iActiveSound;
		int iPreviousSound = SOUNDLIST_EMPTY;

		float minExpireTime = 0.0f;
		int iSoundToFree = SOUNDLIST_EMPTY;
		int iPreviousSoundToFree = SOUNDLIST_EMPTY;

		while (iSound != SOUNDLIST_EMPTY)
		{
			if (pSoundEnt->m_SoundPool[iSound].m_flExpireTime != SOUND_NEVER_EXPIRE)
			{
				if (minExpireTime == 0.0f || pSoundEnt->m_SoundPool[iSound].m_flExpireTime < minExpireTime)
				{
					minExpireTime = pSoundEnt->m_SoundPool[iSound].m_flExpireTime;
					iSoundToFree = iSound;
					iPreviousSoundToFree = iPreviousSound;
				}
			}

			iPreviousSound = iSound;
			iSound = pSoundEnt->m_SoundPool[iSound].m_iNext;
		}

		if (iSoundToFree != SOUNDLIST_EMPTY)
		{
			FreeSound(iSoundToFree, iPreviousSoundToFree);
			ALERT(at_warning, "Taking out an old sound in order to insert a new one\n");

			iThisSound = pSoundEnt->IAllocSound();
			if (iThisSound == SOUNDLIST_EMPTY)
			{
				ALERT(at_error, "Could not AllocSound() even after freeing?!\n");
				return;
			}
		}
		else
			return;
	}

	pSoundEnt->m_SoundPool[iThisSound].m_vecOrigin = vecOrigin;
	pSoundEnt->m_SoundPool[iThisSound].m_iType = iType;
	pSoundEnt->m_SoundPool[iThisSound].m_iVolume = iVolume;
	pSoundEnt->m_SoundPool[iThisSound].m_flExpireTime = gpGlobals->time + flDuration;

	if (displaysoundlist.value >= 1)
	{
		ALERT(at_console, "%s: inserting %s of volume %d at (%g, %g, %g) for %g seconds. Type: ",
			pInitiator ? STRING(pInitiator->pev->classname) : "world",
			pSoundEnt->m_SoundPool[iThisSound].FIsScent() ? "scent" : "sound",
			iVolume, vecOrigin.x, vecOrigin.y, vecOrigin.z, flDuration);

		for (const auto& sound : g_SoundNames)
		{
			if (FBitSet(iType, sound.first))
			{
				ALERT(at_console, "%s; ", sound.second);
			}
		}
		ALERT(at_console, "\n");
	}

	if (displaysoundlist.value >= 2)
	{
		Color3 color{255, 255, 255};
		if (FBitSet(iType, bits_SOUND_DANGER))
			color = Color3{255, 0, 0};
		else if (FBitSet(iType, bits_SOUND_COMBAT))
			color = Color3{255, 170, 0};
		else if (FBitSet(iType, bits_SOUND_MEAT|bits_SOUND_CARCASS))
			color = Color3{255, 85, 127};
		else if (FBitSet(iType, bits_SOUND_PLAYER))
			color = Color3{0, 170, 255};

		const int minVolume = 192;
		const int maxVolume = 512;

		const int volume = clamp(iVolume, minVolume, maxVolume);
		const float volParameter = (volume - minVolume) / static_cast<float>(maxVolume - minVolume);

		const float height = lerp(16.0f, 96.0f, volParameter);
		const float width = lerp(8.0f, 80.0f, volParameter);

		DrawBeamLine(vecOrigin, vecOrigin + Vector(0,0,height), color, flDuration * 10, (int)width);
	}
}

//=========================================================
// Initialize - clears all sounds and moves them into the 
// free sound list.
//=========================================================
void CSoundEnt::Initialize()
{
  	int i;
	int iSound;

	m_cLastActiveSounds = 0;
	m_iFreeSound = 0;
	m_iActiveSound = SOUNDLIST_EMPTY;

	for( i = 0; i < MAX_WORLD_SOUNDS; i++ )
	{
		// clear all sounds, and link them into the free sound list.
		m_SoundPool[i].Clear();
		m_SoundPool[i].m_iNext = i + 1;
	}

	m_SoundPool[i - 1].m_iNext = SOUNDLIST_EMPTY;// terminate the list here.

	// now reserve enough sounds for each client
	for( i = 0; i < gpGlobals->maxClients; i++ )
	{
		iSound = pSoundEnt->IAllocSound();

		if( iSound == SOUNDLIST_EMPTY )
		{
			ALERT( at_console, "Could not AllocSound() for Client Reserve! (DLL)\n" );
			return;
		}

		pSoundEnt->m_SoundPool[iSound].m_flExpireTime = SOUND_NEVER_EXPIRE;
	}
}

//=========================================================
// ISoundsInList - returns the number of sounds in the desired
// sound list.
//=========================================================
int CSoundEnt::ISoundsInList( int iListType )
{
	int i;
	int iThisSound = 0;

	if( iListType == SOUNDLISTTYPE_FREE )
	{
		iThisSound = m_iFreeSound;
	}
	else if( iListType == SOUNDLISTTYPE_ACTIVE )
	{
		iThisSound = m_iActiveSound;
	}
	else
	{
		ALERT( at_console, "Unknown Sound List Type!\n" );
	}

	if( iThisSound == SOUNDLIST_EMPTY )
	{
		return 0;
	}

	i = 0;

	while( iThisSound != SOUNDLIST_EMPTY )
	{
		i++;

		iThisSound = m_SoundPool[iThisSound].m_iNext;
	}

	return i;
}

//=========================================================
// ActiveList - returns the head of the active sound list
//=========================================================
int CSoundEnt::ActiveList()
{
	if( !pSoundEnt )
	{
		return SOUNDLIST_EMPTY;
	}

	return pSoundEnt->m_iActiveSound;
}

//=========================================================
// FreeList - returns the head of the free sound list
//=========================================================
int CSoundEnt::FreeList()
{
	if( !pSoundEnt )
	{
		return SOUNDLIST_EMPTY;
	}

	return pSoundEnt->m_iFreeSound;
}

//=========================================================
// SoundPointerForIndex - returns a pointer to the instance
// of CSound at index's position in the sound pool.
//=========================================================
CSound *CSoundEnt::SoundPointerForIndex( int iIndex )
{
	if( !pSoundEnt )
	{
		return NULL;
	}

	if( iIndex > ( MAX_WORLD_SOUNDS - 1 ) )
	{
		ALERT( at_console, "SoundPointerForIndex() - Index too large!\n" );
		return NULL;
	}

	if( iIndex < 0 )
	{
		ALERT( at_console, "SoundPointerForIndex() - Index < 0!\n" );
		return NULL;
	}

	return &pSoundEnt->m_SoundPool[iIndex];
}

//=========================================================
// Clients are numbered from 1 to MAXCLIENTS, but the client
// reserved sounds in the soundlist are from 0 to MAXCLIENTS - 1,
// so this function ensures that a client gets the proper index
// to his reserved sound in the soundlist.
//=========================================================
int CSoundEnt::ClientSoundIndex( edict_t *pClient )
{
	int iReturn = ENTINDEX( pClient ) - 1;

#if _DEBUG
	if( iReturn < 0 || iReturn > gpGlobals->maxClients )
	{
		ALERT( at_console, "** ClientSoundIndex returning a bogus value! **\n" );
	}
#endif // _DEBUG

	return iReturn;
}

void CSoundEnt::ReportUpdate()
{
	if (!pSoundEnt)
		return;

	if (displaysoundlist.value < 1)
		return;

	const int activeSoundNum = pSoundEnt->ISoundsInList( SOUNDLISTTYPE_ACTIVE );
	if (pSoundEnt->m_cLastActiveSounds != activeSoundNum)
	{
		const int freeSoundNum = pSoundEnt->ISoundsInList( SOUNDLISTTYPE_FREE );
		pSoundEnt->m_cLastActiveSounds = activeSoundNum;
		ALERT(at_aiconsole, "Soundlist: active %d; free %d out of %d\n", activeSoundNum, freeSoundNum, MAX_WORLD_SOUNDS);
	}
}
