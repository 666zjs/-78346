/***
*
*	Copyright (c) 1996-2002, Valve LLC. All rights reserved.
*	
*	This product contains software technology licensed from Id 
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc. 
*	All Rights Reserved.
*
*   Use, distribution, and modification of this source code and/or resulting
*   object code is restricted to non-commercial enhancements to products from
*   Valve LLC.  All other use, distribution, or modification is prohibited
*   without written permission from Valve LLC.
*
****/
/*

===== lights.cpp ========================================================

  spawn and think functions for editor-placed lights

*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"

#define SF_LIGHT_START_OFF		1

class CLight : public CPointEntity
{
public:
	void KeyValue( KeyValueData* pkvd ) override;
	void Spawn() override;
	void Use( CBaseEntity *pActivator, CBaseEntity *pCaller, USE_TYPE useType, float value ) override;

	int Save( CSave &save ) override;
	int Restore( CRestore &restore ) override;

	static TYPEDESCRIPTION m_SaveData[];

private:
	int m_iStyle;
	string_t m_iszPattern;
};

LINK_ENTITY_TO_CLASS( light, CLight )

TYPEDESCRIPTION	CLight::m_SaveData[] =
{
	DEFINE_FIELD( CLight, m_iStyle, FIELD_INTEGER ),
	DEFINE_FIELD( CLight, m_iszPattern, FIELD_STRING ),
};

IMPLEMENT_SAVERESTORE( CLight, CPointEntity )

//
// Cache user-entity-field values until spawn is called.
//
void CLight::KeyValue( KeyValueData* pkvd )
{
	if( FStrEq(pkvd->szKeyName, "style" ) )
	{
		m_iStyle = atoi( pkvd->szValue );
		pkvd->fHandled = true;
	}
	else if( FStrEq(pkvd->szKeyName, "pitch" ) )
	{
		pev->angles.x = atof( pkvd->szValue );
		pkvd->fHandled = true;
	}
	else if( FStrEq(pkvd->szKeyName, "pattern" ) )
	{
		m_iszPattern = ALLOC_STRING( pkvd->szValue );
		pkvd->fHandled = true;
	}
	else
	{
		CPointEntity::KeyValue( pkvd );
	}
}

void CLight::Spawn()
{
	if( FStringNull( pev->targetname ) )
	{
		// inert light
		REMOVE_ENTITY(ENT( pev ) );
		return;
	}

	if( m_iStyle >= 32 )
	{
		//CHANGE_METHOD(ENT(pev), em_use, light_use);
		if( FBitSet( pev->spawnflags, SF_LIGHT_START_OFF ) )
			LIGHT_STYLE( m_iStyle, "a" );
		else if( m_iszPattern )
			LIGHT_STYLE( m_iStyle, STRING( m_iszPattern ) );
		else
			LIGHT_STYLE( m_iStyle, "m" );
	}
}

void CLight::Use( CBaseEntity *pActivator, CBaseEntity *pCaller, USE_TYPE useType, float value )
{
	if( m_iStyle >= 32 )
	{
		if( !ShouldToggle( useType, !FBitSet( pev->spawnflags, SF_LIGHT_START_OFF ) ) )
			return;

		if( FBitSet( pev->spawnflags, SF_LIGHT_START_OFF ) )
		{
			if( m_iszPattern )
				LIGHT_STYLE( m_iStyle, STRING( m_iszPattern ) );
			else
				LIGHT_STYLE( m_iStyle, "m" );
			ClearBits( pev->spawnflags, SF_LIGHT_START_OFF );
		}
		else
		{
			LIGHT_STYLE( m_iStyle, "a" );
			SetBits( pev->spawnflags, SF_LIGHT_START_OFF );
		}
	}
}

//
// shut up spawn functions for new spotlights
//
LINK_ENTITY_TO_CLASS( light_spot, CLight )

class CEnvLight : public CLight
{
public:
	void KeyValue( KeyValueData* pkvd ) override;
	void Spawn() override;
};

LINK_ENTITY_TO_CLASS( light_environment, CEnvLight )

void CEnvLight::KeyValue( KeyValueData* pkvd )
{
	if( FStrEq(pkvd->szKeyName, "_light" ) )
	{
		int r, g, b, v, j;
		char szColor[64];
		j = sscanf( pkvd->szValue, "%d %d %d %d\n", &r, &g, &b, &v );
		if( j == 1 )
		{
			g = b = r;
		}
		else if( j == 4 )
		{
			float vf = v / 255.0f;
			r *= vf;
			g *= vf;
			b *= vf;
		}

		// simulate qrad direct, ambient,and gamma adjustments, as well as engine scaling
		r = (int)( pow( r / 114.0f, 0.6f ) * 264.0f );
		g = (int)( pow( g / 114.0f, 0.6f ) * 264.0f );
		b = (int)( pow( b / 114.0f, 0.6f ) * 264.0f );

		pkvd->fHandled = true;
		sprintf( szColor, "%d", r );
		CVAR_SET_STRING( "sv_skycolor_r", szColor );
		sprintf( szColor, "%d", g );
		CVAR_SET_STRING( "sv_skycolor_g", szColor );
		sprintf( szColor, "%d", b );
		CVAR_SET_STRING( "sv_skycolor_b", szColor );
	}
	else
	{
		CLight::KeyValue( pkvd );
	}
}

void CEnvLight::Spawn()
{
	char szVector[64];
	UTIL_MakeAimVectors( pev->angles );

	sprintf( szVector, "%f", (double)gpGlobals->v_forward.x );
	CVAR_SET_STRING( "sv_skyvec_x", szVector );
	sprintf( szVector, "%f", (double)gpGlobals->v_forward.y );
	CVAR_SET_STRING( "sv_skyvec_y", szVector );
	sprintf( szVector, "%f", (double)gpGlobals->v_forward.z );
	CVAR_SET_STRING( "sv_skyvec_z", szVector );

	CLight::Spawn();
}
