/***
*
*	Copyright (c) 1996-2002, Valve LLC. All rights reserved.
*	
*	This product contains software technology licensed from Id 
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc. 
*	All Rights Reserved.
*
*   Use, distribution, and modification of this source code and/or resulting
*   object code is restricted to non-commercial enhancements to products from
*   Valve LLC.  All other use, distribution, or modification is prohibited
*   without written permission from Valve LLC.
*
****/
//=========================================================
// Hornets
//=========================================================

#include	"extdll.h"
#include	"util.h"
#include	"cbase.h"
#include	"monsters.h"
#include	"soundent.h"
#include	"hornet.h"
#include	"gamerules.h"
#include	"visuals_utils.h"

LINK_ENTITY_TO_CLASS( hornet, CHornet )

//=========================================================
// Save/Restore
//=========================================================
TYPEDESCRIPTION	CHornet::m_SaveData[] =
{
	DEFINE_FIELD( CHornet, m_flStopAttack, FIELD_TIME ),
	DEFINE_FIELD( CHornet, m_iHornetType, FIELD_INTEGER ),
	DEFINE_FIELD( CHornet, m_flFlySpeed, FIELD_FLOAT ),
};

IMPLEMENT_SAVERESTORE( CHornet, CBaseMonster )

const NamedSoundScript CHornet::buzzSoundScript = {
	CHAN_VOICE,
	{"hornet/ag_buzz1.wav", "hornet/ag_buzz2.wav", "hornet/ag_buzz3.wav"},
	HORNET_BUZZ_VOLUME,
	ATTN_NORM,
	"Hornet.Buzz"
};

const NamedSoundScript CHornet::dieSoundScript = {
	CHAN_VOICE,
	{"hornet/ag_hornethit1.wav", "hornet/ag_hornethit2.wav", "hornet/ag_hornethit3.wav"},
	1.0f,
	ATTN_NORM,
	"Hornet.Die"
};

const NamedVisual CHornet::modelVisual = BuildVisual("Hornet.Model")
		.Model("models/hornet.mdl");

const NamedVisual CHornet::sharedTrailVisual = BuildVisual("Hornet.TrailBase")
		.Model("sprites/laserbeam.spr")
		.Alpha(128)
		.BeamParams(2, 0)
		.Life(1.0f);

const NamedVisual CHornet::trailVisual = BuildVisual("Hornet.Trail")
		.RenderColor(179, 39, 14)
		.Mixin(&CHornet::sharedTrailVisual);

const NamedVisual CHornet::trailAltVisual = BuildVisual("Hornet.TrailAlt")
		.RenderColor(255, 128, 0)
		.Mixin(&CHornet::sharedTrailVisual);

const NamedVisual CHornet::puffVisual = BuildVisual("Hornet.Puff")
		.Model("sprites/muz1.spr")
		.RenderMode(kRenderTransAdd)
		.Scale(0.2f)
		.Alpha(128);

//=========================================================
// don't let hornets gib, ever.
//=========================================================
TakeDamageResult CHornet::TakeDamage( entvars_t *pevInflictor, entvars_t *pevAttacker, const DamageInfo& damageInfo )
{
	DamageInfo dmgInfo = damageInfo;
	dmgInfo.SetGibPolicy(GIB_NEVER);

	return CBaseMonster::TakeDamage( pevInflictor, pevAttacker, dmgInfo );
}

//=========================================================
//=========================================================
void CHornet::Spawn()
{
	Precache();

	pev->movetype = MOVETYPE_FLY;
	pev->solid = SOLID_BBOX;
	pev->takedamage = DAMAGE_YES;
	pev->flags |= FL_MONSTER;
	pev->health = 1;// weak!

	if( g_pGameRules->IsMultiplayer() )
	{
		// hornets don't live as long in multiplayer
		m_flStopAttack = gpGlobals->time + 3.5f;
	}
	else
	{
		m_flStopAttack	= gpGlobals->time + 5.0f;
	}

	SetMyFieldOfView(0.9f); // +- 25 degrees

	if( RANDOM_LONG( 1, 5 ) <= 2 )
	{
		m_iHornetType = HORNET_TYPE_RED;
		m_flFlySpeed = HORNET_RED_SPEED;
	}
	else
	{
		m_iHornetType = HORNET_TYPE_ORANGE;
		m_flFlySpeed = HORNET_ORANGE_SPEED;
	}

	ApplyVisualWithOwn(GetVisual(modelVisual));
	UTIL_SetSize( pev, Vector( -4, -4, -4 ), Vector( 4, 4, 4 ) );

	SetTouch( &CHornet::DieTouch );
	SetThink( &CHornet::StartTrack );

	/*edict_t *pSoundEnt = pev->owner;
	if( !pSoundEnt )
		pSoundEnt = edict();*/

	if( !FNullEnt( pev->owner ) && ( pev->owner->v.flags & FL_CLIENT ) )
	{
		SetDefaultProjectileDamage(GetSkillValue("plr_hornet_dmg"));
	}
	else
	{
		// no real owner, or owner isn't a client.
		SetDefaultProjectileDamage(GetSkillValue("hornet_dmg"));
	}

	pev->nextthink = gpGlobals->time + 0.1f;
	ResetSequenceInfo();
}

void CHornet::Precache()
{
	RegisterVisualAsMineOwn(modelVisual);

	RegisterAndPrecacheSoundScript(buzzSoundScript);
	RegisterAndPrecacheSoundScript(dieSoundScript);

	RegisterVisual(puffVisual);
	RegisterVisual(trailVisual);
	RegisterVisual(trailAltVisual);
}

//=========================================================
// hornets will never get mad at each other, no matter who the owner is.
//=========================================================
int CHornet::IRelationship( CBaseEntity *pTarget )
{
	if( pTarget->pev->modelindex == pev->modelindex )
	{
		return R_NO;
	}

	// When hornets have a custom class, they perceieve other monsters from the point of view of this class
	if (m_iClass || m_reverseRelationship)
	{
		const int classify = CBaseMonster::Classify();
		return CBaseMonster::IDefaultRelationship(classify, pTarget->Classify());
	}

	return CBaseMonster::IRelationship( pTarget );
}

//=========================================================
// ID's Hornet as their owner
//=========================================================
int CHornet::DefaultClassify()
{
	if( pev->owner && pev->owner->v.flags & FL_CLIENT )
	{
		return CLASS_PLAYER_BIOWEAPON;
	}

	return	CLASS_ALIEN_BIOWEAPON;
}

// Other monsters always perceieve hornets as bioweapon
int CHornet::Classify()
{
	return DefaultClassify();
}

void CHornet::LaunchAsProjectile(const ProjectileParameters& params)
{
	const float defaultSpeed = params.variant == DART ? 1200.0f : 300.0f;
	LaunchAsProjectileImpl(defaultSpeed, params);
	if (params.variant == DART)
		SetThink( &CHornet::StartDart );
}

//=========================================================
// StartTrack - starts a hornet out tracking its target
//=========================================================
void CHornet::StartTrack()
{
	IgniteTrail();

	SetTouch( &CHornet::TrackTouch );
	SetThink( &CHornet::TrackTarget );

	pev->nextthink = gpGlobals->time + 0.1f;
}

//=========================================================
// StartDart - starts a hornet out just flying straight.
//=========================================================
void CHornet::StartDart()
{
	IgniteTrail();

	SetTouch( &CHornet::DartTouch );

	SetThink( &CBaseEntity::SUB_Remove );
	pev->nextthink = gpGlobals->time + 4.0f;
}

void CHornet::IgniteTrail()
{
/*

  ted's suggested trail colors:

r161
g25
b97

r173
g39
b14

old colors
		case HORNET_TYPE_RED:
			WRITE_BYTE( 255 );   // r, g, b
			WRITE_BYTE( 128 );   // r, g, b
			WRITE_BYTE( 0 );   // r, g, b
			break;
		case HORNET_TYPE_ORANGE:
			WRITE_BYTE( 0 );   // r, g, b
			WRITE_BYTE( 100 );   // r, g, b
			WRITE_BYTE( 255 );   // r, g, b
			break;

*/
	// trail
	const Visual* visual;
	if (m_iHornetType == HORNET_TYPE_RED)
	{
		visual = GetVisual(trailVisual);
	}
	else
	{
		visual = GetVisual(trailAltVisual);
	}
	SendBeamFollow(entindex(), visual);
}

//=========================================================
// Hornet is flying, gently tracking target
//=========================================================
void CHornet::TrackTarget()
{
	Vector	vecFlightDir;
	Vector	vecDirToEnemy;
	float	flDelta;

	StudioFrameAdvance();

	if( gpGlobals->time > m_flStopAttack )
	{
		SetTouch( NULL );
		SetThink( &CBaseEntity::SUB_Remove );
		pev->nextthink = gpGlobals->time + 0.1f;
		return;
	}

	// UNDONE: The player pointer should come back after returning from another level
	if( m_hEnemy == 0 )
	{
		// enemy is dead.
		Look( 512 );
		m_hEnemy = BestVisibleEnemy();
	}

	if( m_hEnemy != 0 && FVisible( m_hEnemy ) )
	{
		m_vecEnemyLKP = m_hEnemy->BodyTarget( pev->origin );
	}
	else
	{
		m_vecEnemyLKP = m_vecEnemyLKP + pev->velocity * m_flFlySpeed * 0.1f;
	}

	vecDirToEnemy = ( m_vecEnemyLKP - pev->origin ).Normalize();

	if( pev->velocity.IsLengthLessThan(0.1f) )
		vecFlightDir = vecDirToEnemy;
	else 
		vecFlightDir = pev->velocity.Normalize();

	// measure how far the turn is, the wider the turn, the slow we'll go this time.
	flDelta = DotProduct( vecFlightDir, vecDirToEnemy );

	if( flDelta < 0.5f )
	{
		// hafta turn wide again. play sound
		EmitSoundScript(buzzSoundScript);
	}

	if( flDelta <= 0 && m_iHornetType == HORNET_TYPE_RED )
	{
		// no flying backwards, but we don't want to invert this, cause we'd go fast when we have to turn REAL far.
		flDelta = 0.25f;
	}

	pev->velocity = ( vecFlightDir + vecDirToEnemy ).Normalize();

	if( pev->owner && ( pev->owner->v.flags & FL_MONSTER ) )
	{
		// random pattern only applies to hornets fired by monsters, not players. 
		pev->velocity.x += RANDOM_FLOAT( -0.10f, 0.10f );// scramble the flight dir a bit.
		pev->velocity.y += RANDOM_FLOAT( -0.10f, 0.10f );
		pev->velocity.z += RANDOM_FLOAT( -0.10f, 0.10f );
	}

	switch( m_iHornetType )
	{
		case HORNET_TYPE_RED:
			pev->velocity = pev->velocity * ( m_flFlySpeed * flDelta );// scale the dir by the ( speed * width of turn )
			pev->nextthink = gpGlobals->time + RANDOM_FLOAT( 0.1f, 0.3f );
			break;
		case HORNET_TYPE_ORANGE:
			pev->velocity = pev->velocity * m_flFlySpeed;// do not have to slow down to turn.
			pev->nextthink = gpGlobals->time + 0.1f;// fixed think time
			break;
	}

	pev->angles = UTIL_VecToAngles( pev->velocity );

	pev->solid = SOLID_BBOX;

	// if hornet is close to the enemy, jet in a straight line for a half second.
	// (only in the single player game)
	if( m_hEnemy != 0 && !g_pGameRules->IsMultiplayer() )
	{
		if( flDelta >= 0.4f && ( pev->origin - m_vecEnemyLKP ).IsLengthLessThanOrEqual(300) )
		{
			SendSprite(pev->origin, GetVisual(puffVisual));

			EmitSoundScript(buzzSoundScript);
			pev->velocity = pev->velocity * 2.0f;
			pev->nextthink = gpGlobals->time + 1.0f;
			// don't attack again
			m_flStopAttack = gpGlobals->time;
		}
	}
}

//=========================================================
// Tracking Hornet hit something
//=========================================================
void CHornet::TrackTouch( CBaseEntity *pOther )
{
	if( pOther->edict() == pev->owner || pOther->pev->modelindex == pev->modelindex )
	{
		// bumped into the guy that shot it.
		pev->solid = SOLID_NOT;
		return;
	}

	if( IRelationship( pOther ) <= R_NO )
	{
		// hit something we don't want to hurt, so turn around.

		pev->velocity.NormalizeInPlace();

		pev->velocity.x *= -1.0f;
		pev->velocity.y *= -1.0f;

		pev->origin = pev->origin + pev->velocity * 4.0f; // bounce the hornet off a bit.
		pev->velocity = pev->velocity * m_flFlySpeed;

		return;
	}

	DieTouch( pOther );
}

void CHornet::DartTouch( CBaseEntity *pOther )
{
	DieTouch( pOther );
}

void CHornet::DieTouch( CBaseEntity *pOther )
{
	if( pOther && pOther->pev->takedamage && pev->owner )
	{
		// do the damage
		EmitSoundScript(dieSoundScript);

		pOther->TakeDamage( pev, VARS( pev->owner ), DamageInfo(GetProjectileDamage(), DMG_BULLET) );
	}

	pev->modelindex = 0;// so will disappear for the 0.1 secs we wait until NEXTTHINK gets rid
	pev->solid = SOLID_NOT;

	SetThink( &CBaseEntity::SUB_Remove );
	pev->nextthink = gpGlobals->time + 1.0f;// stick around long enough for the sound to finish!
}
