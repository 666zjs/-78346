/***
*
*	Copyright (c) 1996-2002, Valve LLC. All rights reserved.
*	
*	This product contains software technology licensed from Id 
*	Software, Inc. ("Id Technology").  Id Technology (c) 1996 Id Software, Inc. 
*	All Rights Reserved.
*
*   Use, distribution, and modification of this source code and/or resulting
*   object code is restricted to non-commercial enhancements to products from
*   Valve LLC.  All other use, distribution, or modification is prohibited
*   without written permission from Valve LLC.
*
****/
/*

===== bmodels.cpp ========================================================

  spawn, think, and use functions for entities that use brush models

*/

#include "extdll.h"
#include "util.h"
#include "cbase.h"
#include "doors.h"
#include "nodes.h"

extern DLL_GLOBAL Vector		g_vecAttackDir;

#define SF_BRUSH_ROTATE_Y_AXIS		0
#define SF_BRUSH_ROTATE_INSTANT		1
#define SF_BRUSH_ROTATE_BACKWARDS	2
#define SF_BRUSH_ROTATE_Z_AXIS		4
#define SF_BRUSH_ROTATE_X_AXIS		8
#define SF_BRUSH_ACCDCC	16// brush should accelerate and decelerate when toggled
#define SF_BRUSH_HURT		32// rotating brush that inflicts pain based on rotation speed
#define SF_ROTATING_NOT_SOLID	64	// some special rotating objects are not solid.
#define SF_ROTATING_LIMIG_BLOCKING_DAMAGE 4096

#define SF_PENDULUM_AUTO_RETURN		16
#define	SF_PENDULUM_PASSABLE		32

#define SF_BRUSH_ROTATE_SMALLRADIUS	128
#define SF_BRUSH_ROTATE_MEDIUMRADIUS 256
#define SF_BRUSH_ROTATE_LARGERADIUS 512

// covering cheesy noise1, noise2, & noise3 fields so they make more sense (for rotating fans)
#define		noiseStart		noise1
#define		noiseStop		noise2
#define		noiseRunning	noise3

#define		SF_PENDULUM_SWING		2	// spawnflag that makes a pendulum a rope swing.
//
// BModelOrigin - calculates origin of a bmodel from absmin/size because all bmodel origins are 0 0 0
//
Vector VecBModelOrigin( entvars_t* pevBModel )
{
	return pevBModel->absmin + ( pevBModel->size * 0.5f );
}

// =================== FUNC_WALL ==============================================

#define SF_FUNCWALL_USE_ANGLES 2

class CFuncWall : public CBaseEntity
{
public:
	void Spawn() override;
	void Use( CBaseEntity *pActivator, CBaseEntity *pCaller, USE_TYPE useType, float value ) override;

	// Bmodels don't go across transitions
	int ObjectCaps() override { return CBaseEntity :: ObjectCaps() & ~FCAP_ACROSS_TRANSITION; }
};

LINK_ENTITY_TO_CLASS( func_wall, CFuncWall )

void CFuncWall::Spawn()
{
	if (!FBitSet(pev->spawnflags, SF_FUNCWALL_USE_ANGLES))
		pev->angles = g_vecZero;
	pev->movetype = MOVETYPE_PUSH;  // so it doesn't get pushed by anything
	pev->solid = SOLID_BSP;
	SET_MODEL( ENT( pev ), STRING( pev->model ) );

	// If it can't move/go away, it's really part of the world
	pev->flags |= FL_WORLDBRUSH;
}

void CFuncWall::Use( CBaseEntity *pActivator, CBaseEntity *pCaller, USE_TYPE useType, float value )
{
	if( ShouldToggle( useType, (int)pev->frame != 0 ) )
		pev->frame = 1 - pev->frame;
}

#define SF_WALL_START_OFF		0x0001

class CFuncWallToggle : public CFuncWall
{
public:
	void Spawn() override;
	void Use( CBaseEntity *pActivator, CBaseEntity *pCaller, USE_TYPE useType, float value ) override;
	NODE_LINKENT HandleLinkEnt(int afCapMask, bool nodeQueryStatic) override;
	void TurnOff();
	void TurnOn();
	bool IsOn();
};

LINK_ENTITY_TO_CLASS( func_wall_toggle, CFuncWallToggle )

void CFuncWallToggle::Spawn()
{
	CFuncWall::Spawn();
	if( pev->spawnflags & SF_WALL_START_OFF )
		TurnOff();
}

void CFuncWallToggle::TurnOff()
{
	pev->solid = SOLID_NOT;
	pev->effects |= EF_NODRAW;
	UTIL_SetOrigin( pev, pev->origin );
	WorldGraph.ResetNearestNodeCache();
}

void CFuncWallToggle::TurnOn()
{
	pev->solid = SOLID_BSP;
	pev->effects &= ~EF_NODRAW;
	UTIL_SetOrigin( pev, pev->origin );
	WorldGraph.ResetNearestNodeCache();
}

bool CFuncWallToggle::IsOn()
{
	if( pev->solid == SOLID_NOT )
		return false;
	return true;
}

void CFuncWallToggle::Use( CBaseEntity *pActivator, CBaseEntity *pCaller, USE_TYPE useType, float value )
{
	bool status = IsOn();

	if( ShouldToggle( useType, status ) )
	{
		if( status )
			TurnOff();
		else
			TurnOn();
	}
}

NODE_LINKENT CFuncWallToggle::HandleLinkEnt(int afCapMask, bool nodeQueryStatic)
{
	if (nodeQueryStatic) {
		return NLE_ALLOW;
	}
	if (!IsOn()) {
		return NLE_ALLOW;
	}
	return NLE_PROHIBIT;
}

#define SF_CONVEYOR_VISUAL	0x0001
#define SF_CONVEYOR_NOTSOLID	0x0002

class CFuncConveyor : public CFuncWall
{
public:
	enum {
		CONV_USE_SET_DEFAULT,
		CONV_USE_SET_SET = 1,
		CONV_USE_SET_ADD = 2
	};

	void Spawn() override;
	void KeyValue(KeyValueData* pkvd) override;
	void Use( CBaseEntity *pActivator, CBaseEntity *pCaller, USE_TYPE useType, float value ) override;
	void UpdateSpeed( float speed );

	int Save( CSave &save ) override;
	int Restore( CRestore &restore ) override;
	static TYPEDESCRIPTION m_SaveData[];

	short m_useSetPolicy;
};

TYPEDESCRIPTION	CFuncConveyor::m_SaveData[] =
{
	DEFINE_FIELD( CFuncConveyor, m_useSetPolicy, FIELD_SHORT )
};
IMPLEMENT_SAVERESTORE( CFuncConveyor, CFuncWall )

LINK_ENTITY_TO_CLASS( func_conveyor, CFuncConveyor )

void CFuncConveyor::Spawn()
{
	SetMovedir( pev );
	CFuncWall::Spawn();

	if( !( pev->spawnflags & SF_CONVEYOR_VISUAL ) )
		SetBits( pev->flags, FL_CONVEYOR );

	// HACKHACK - This is to allow for some special effects
	if( pev->spawnflags & SF_CONVEYOR_NOTSOLID )
	{
		pev->solid = SOLID_NOT;
		pev->skin = 0;		// Don't want the engine thinking we've got special contents on this brush
	}

	if( pev->speed == 0.0f )
		pev->speed = 100.0f;

	UpdateSpeed( pev->speed );
}

void CFuncConveyor::KeyValue(KeyValueData *pkvd)
{
	if (FStrEq(pkvd->szKeyName, "useset_policy"))
	{
		m_useSetPolicy = (short)atoi(pkvd->szValue);
		pkvd->fHandled = true;
	}
	else
		CBaseEntity::KeyValue(pkvd);
}

// HACKHACK -- This is ugly, but encode the speed in the rendercolor to avoid adding more data to the network stream
void CFuncConveyor::UpdateSpeed( float speed )
{
	// Encode it as an integer with 4 fractional bits
	int speedCode = (int)( fabs( speed ) * 16.0f );

	if( speed < 0 )
		pev->rendercolor.x = 1;
	else
		pev->rendercolor.x = 0;

	pev->rendercolor.y = speedCode >> 8;
	pev->rendercolor.z = speedCode & 0xFF;
}

void CFuncConveyor::Use( CBaseEntity *pActivator, CBaseEntity *pCaller, USE_TYPE useType, float value )
{
	if (useType == USE_SET)
	{
		switch(m_useSetPolicy)
		{
		case CONV_USE_SET_SET:
			pev->speed = value;
			UpdateSpeed(pev->speed);
			return;
		case CONV_USE_SET_ADD:
			pev->speed += value;
			UpdateSpeed(pev->speed);
			return;
		default:
			break;
		}
	}

	pev->speed = -pev->speed;
	UpdateSpeed( pev->speed );
}

// =================== FUNC_ILLUSIONARY ==============================================

class CFuncIllusionary : public CBaseToggle 
{
public:
	void Spawn() override;
	void EXPORT SloshTouch( CBaseEntity *pOther );
	void KeyValue( KeyValueData *pkvd ) override;
	int ObjectCaps() override { return CBaseEntity :: ObjectCaps() & ~FCAP_ACROSS_TRANSITION; }
};

LINK_ENTITY_TO_CLASS( func_illusionary, CFuncIllusionary )

void CFuncIllusionary::KeyValue( KeyValueData *pkvd )
{
	if( FStrEq( pkvd->szKeyName, "skin" ) )//skin is used for content type
	{
		pev->skin = atoi( pkvd->szValue );
		pkvd->fHandled = true;
	}
	else
		CBaseToggle::KeyValue( pkvd );
}

void CFuncIllusionary::Spawn()
{
	if (!FBitSet(pev->spawnflags, SF_FUNCWALL_USE_ANGLES))
		pev->angles = g_vecZero;
	pev->movetype = MOVETYPE_NONE;  
	pev->solid = SOLID_NOT;// always solid_not 
	SET_MODEL( ENT( pev ), STRING( pev->model ) );

	// I'd rather eat the network bandwidth of this than figure out how to save/restore
	// these entities after they have been moved to the client, or respawn them ala Quake
	// Perhaps we can do this in deathmatch only.
	//	MAKE_STATIC(ENT(pev));
}

class CFuncIllusionaryToggle : public CFuncIllusionary
{
public:
	void Spawn() override
	{
		CFuncIllusionary::Spawn();
		if( pev->spawnflags & SF_WALL_START_OFF )
			TurnOff();
	}
	void Use( CBaseEntity *pActivator, CBaseEntity *pCaller, USE_TYPE useType, float value ) override
	{
		bool status = IsOn();
		if( ShouldToggle( useType, status ) )
		{
			if( status )
				TurnOff();
			else
				TurnOn();
		}
	}
	void TurnOff() {  pev->effects |= EF_NODRAW; }
	void TurnOn() { pev->effects &= ~EF_NODRAW; }
	bool IsOn() { return !(pev->effects & EF_NODRAW); }
};

LINK_ENTITY_TO_CLASS( func_illusionary_toggle, CFuncIllusionaryToggle )

// -------------------------------------------------------------------------------
//
// Monster only clip brush
// 
// This brush will be solid for any entity who has the FL_MONSTERCLIP flag set
// in pev->flags
//
// otherwise it will be invisible and not solid.  This can be used to keep 
// specific monsters out of certain areas
//
// -------------------------------------------------------------------------------
class CFuncMonsterClip : public CFuncWall
{
public:
	void Spawn() override;
	void Use( CBaseEntity *pActivator, CBaseEntity *pCaller, USE_TYPE useType, float value ) override {}		// Clear out func_wall's use function
	NODE_LINKENT HandleLinkEnt(int afCapMask, bool nodeQueryStatic) override;
};

LINK_ENTITY_TO_CLASS( func_monsterclip, CFuncMonsterClip )

void CFuncMonsterClip::Spawn()
{
	CFuncWall::Spawn();
	if( CVAR_GET_FLOAT( "showtriggers" ) == 0 )
		pev->effects = EF_NODRAW;
	pev->flags = FL_MONSTERCLIP;
}

NODE_LINKENT CFuncMonsterClip::HandleLinkEnt(int afCapMask, bool nodeQueryStatic)
{
	if (nodeQueryStatic)
		return NLE_ALLOW;
	if (afCapMask & bits_CAP_MONSTERCLIPPED)
		return NLE_PROHIBIT;
	return NLE_ALLOW;
}

// =================== FUNC_ROTATING ==============================================
#define ROTATING_BLOCKING_ENT_NUM 4

class CFuncRotating : public CBaseEntity
{
public:
	// basic functions
	void Spawn() override;
	void Precache() override;
	void EXPORT SpinUp();
	void EXPORT SpinDown();
	void KeyValue( KeyValueData* pkvd) override;
	void EXPORT HurtTouch( CBaseEntity *pOther );
	void EXPORT RotatingUse( CBaseEntity *pActivator, CBaseEntity *pCaller, USE_TYPE useType, float value );
	void EXPORT Rotate();
	void RampPitchVol(bool fUp );
	void Blocked( CBaseEntity *pOther ) override;
	int ObjectCaps() override { return CBaseEntity :: ObjectCaps() & ~FCAP_ACROSS_TRANSITION; }
	int Save( CSave &save ) override;
	int Restore( CRestore &restore ) override;

	static TYPEDESCRIPTION m_SaveData[];

	float m_flFanFriction;
	float m_flAttenuation;
	float m_flVolume;
	float m_pitch;
	int m_sounds;
	int m_blockingEntities[ROTATING_BLOCKING_ENT_NUM];
	float m_blockingTimes[ROTATING_BLOCKING_ENT_NUM];
};

TYPEDESCRIPTION	CFuncRotating::m_SaveData[] =
{
	DEFINE_FIELD( CFuncRotating, m_flFanFriction, FIELD_FLOAT ),
	DEFINE_FIELD( CFuncRotating, m_flAttenuation, FIELD_FLOAT ),
	DEFINE_FIELD( CFuncRotating, m_flVolume, FIELD_FLOAT ),
	DEFINE_FIELD( CFuncRotating, m_pitch, FIELD_FLOAT ),
	DEFINE_FIELD( CFuncRotating, m_sounds, FIELD_INTEGER ),
	DEFINE_ARRAY( CFuncRotating, m_blockingEntities, FIELD_INTEGER, ROTATING_BLOCKING_ENT_NUM ),
	DEFINE_ARRAY( CFuncRotating, m_blockingTimes, FIELD_TIME, ROTATING_BLOCKING_ENT_NUM ),

};

IMPLEMENT_SAVERESTORE( CFuncRotating, CBaseEntity )

LINK_ENTITY_TO_CLASS( func_rotating, CFuncRotating )

void CFuncRotating::KeyValue( KeyValueData* pkvd )
{
	if( FStrEq( pkvd->szKeyName, "fanfriction" ) )
	{
		m_flFanFriction = atof( pkvd->szValue ) * 0.01f;
		pkvd->fHandled = true;
	}
	else if( FStrEq( pkvd->szKeyName, "Volume" ) )
	{
		m_flVolume = atof( pkvd->szValue ) * 0.1f;

		if( m_flVolume > 1.0f )
			m_flVolume = 1.0f;
		if( m_flVolume < 0.0f )
			m_flVolume = 0.0f;
		pkvd->fHandled = true;
	}
	else if( FStrEq( pkvd->szKeyName, "spawnorigin" ) )
	{
		Vector tmp;
		UTIL_StringToVector( (float *)tmp, pkvd->szValue );
		if( tmp != g_vecZero )
			pev->origin = tmp;
	}
	else if( FStrEq( pkvd->szKeyName, "sounds" ) )
	{
		m_sounds = atoi( pkvd->szValue );
		pkvd->fHandled = true;
	}
	else 
		CBaseEntity::KeyValue( pkvd );
}

void CFuncRotating::Spawn()
{
	// set final pitch.  Must not be PITCH_NORM, since we
	// plan on pitch shifting later.
	m_pitch = PITCH_NORM - 1;

	// maintain compatibility with previous maps
	if( m_flVolume == 0.0f )
		m_flVolume = 1.0f;

	// if the designer didn't set a sound attenuation, default to one.
	m_flAttenuation = ATTN_NORM;
	
	if( FBitSet( pev->spawnflags, SF_BRUSH_ROTATE_SMALLRADIUS) )
	{
		m_flAttenuation = ATTN_IDLE;
	}
	else if( FBitSet( pev->spawnflags, SF_BRUSH_ROTATE_MEDIUMRADIUS ) )
	{
		m_flAttenuation = ATTN_STATIC;
	}
	else if( FBitSet( pev->spawnflags, SF_BRUSH_ROTATE_LARGERADIUS ) )
	{
		m_flAttenuation = ATTN_NORM;
	}

	// prevent divide by zero if level designer forgets friction!
	if( m_flFanFriction == 0.0f )
	{
		m_flFanFriction = 1.0f;
	}

	if( FBitSet( pev->spawnflags, SF_BRUSH_ROTATE_Z_AXIS ) )
		pev->movedir = Vector( 0.0f, 0.0f, 1.0f );
	else if( FBitSet( pev->spawnflags, SF_BRUSH_ROTATE_X_AXIS ) )
		pev->movedir = Vector( 1.0f, 0.0f, 0.0f );
	else 
		pev->movedir = Vector( 0.0f, 1.0f, 0.0f );	// y-axis

	// check for reverse rotation
	if( FBitSet( pev->spawnflags, SF_BRUSH_ROTATE_BACKWARDS ) )
		pev->movedir = pev->movedir * -1.0f;

	// some rotating objects like fake volumetric lights will not be solid.
	if( FBitSet( pev->spawnflags, SF_ROTATING_NOT_SOLID ) )
	{
		pev->solid = SOLID_NOT;
		pev->skin = CONTENTS_EMPTY;
		pev->movetype = MOVETYPE_PUSH;
	}
	else
	{
		pev->solid = SOLID_BSP;
		pev->movetype = MOVETYPE_PUSH;
	}

	UTIL_SetOrigin( pev, pev->origin );
	SET_MODEL( ENT( pev ), STRING( pev->model ) );

	SetUse( &CFuncRotating::RotatingUse );
	// did level designer forget to assign speed?
	if( pev->speed <= 0.0f )
		pev->speed = 0.0f;

	// Removed this per level designers request.  -- JAY
	//	if( pev->dmg == 0 )
	//		pev->dmg = 2;

	// instant-use brush?
	if( FBitSet( pev->spawnflags, SF_BRUSH_ROTATE_INSTANT ) )
	{
		SetThink( &CBaseEntity::SUB_CallUseToggle );
		pev->nextthink = pev->ltime + 1.5f;	// leave a magic delay for client to start up
	}
	// can this brush inflict pain?
	if( FBitSet( pev->spawnflags, SF_BRUSH_HURT ) )
	{
		SetTouch( &CFuncRotating::HurtTouch );
	}

	Precache();
}

void CFuncRotating::Precache()
{
	const char* szSoundFile = STRING( pev->message );
	bool NullSound = false;

	// set up fan sounds
	if( !FStringNull( pev->message ) && szSoundFile[0] != '\0' )
	{
		// if a path is set for a wave, use it
	}
	else
	{
		// otherwise use preset sound
		switch( m_sounds )
		{
		case 1:
			szSoundFile = "fans/fan1.wav";
			break;
		case 2:
			szSoundFile = "fans/fan2.wav";
			break;
		case 3:
			szSoundFile = "fans/fan3.wav";
			break;
		case 4:
			szSoundFile = "fans/fan4.wav";
			break;
		case 5:
			szSoundFile = "fans/fan5.wav";
			break;
		case 0:
		default:
			szSoundFile = "common/null.wav";
			NullSound = true;
			break;
		}
	}

	if( !NullSound )
		PRECACHE_SOUND( szSoundFile );
	pev->noiseRunning = MAKE_STRING( szSoundFile );

	if( pev->avelocity != g_vecZero )
	{
		// if fan was spinning, and we went through transition or save/restore,
		// make sure we restart the sound.  1.5 sec delay is magic number. KDB

		SetThink( &CFuncRotating::SpinUp );
		pev->nextthink = pev->ltime + 1.5f;
	}
}

//
// Touch - will hurt others based on how fast the brush is spinning
//
void CFuncRotating::HurtTouch( CBaseEntity *pOther )
{
	entvars_t *pevOther = pOther->pev;

	// we can't hurt this thing, so we're not concerned with it
	if( !pevOther->takedamage )
		return;

	// calculate damage based on rotation speed
	pev->dmg = pev->avelocity.Length() / 10;

	pOther->TakeDamage( pev, pev, DamageInfo(pev->dmg, DMG_CRUSH) );

	pevOther->velocity = ( pevOther->origin - VecBModelOrigin( pev ) ).Normalize() * pev->dmg;
}

//
// RampPitchVol - ramp pitch and volume up to final values, based on difference
// between how fast we're going vs how fast we plan to go
//
#define FANPITCHMIN		30
#define FANPITCHMAX		100

void CFuncRotating::RampPitchVol( bool fUp )
{
	Vector vecAVel = pev->avelocity;
	float vecCur;
	float vecFinal;
	float fpct;
	float fvol;
	float fpitch;
	int pitch;

	// get current angular velocity
	vecCur = fabs( vecAVel.x != 0 ? vecAVel.x : ( vecAVel.y != 0 ? vecAVel.y : vecAVel.z ) );

	// get target angular velocity
	vecFinal = ( pev->movedir.x != 0 ? pev->movedir.x : ( pev->movedir.y != 0 ? pev->movedir.y : pev->movedir.z ) );
	vecFinal *= pev->speed;
	vecFinal = fabs( vecFinal );

	// calc volume and pitch as % of final vol and pitch
	fpct = vecCur / vecFinal;
	//if (fUp)
	//	fvol = m_flVolume * (0.5f + fpct/2.0f); // spinup volume ramps up from 50% max vol
	//else
		fvol = m_flVolume * fpct;			  // slowdown volume ramps down to 0

	fpitch = FANPITCHMIN + ( FANPITCHMAX - FANPITCHMIN ) * fpct;	

	pitch = (int)fpitch;
	if( pitch == PITCH_NORM )
		pitch = PITCH_NORM - 1;

	// change the fan's vol and pitch
	EMIT_SOUND_DYN( ENT( pev ), CHAN_STATIC, STRING( pev->noiseRunning ), 
		fvol, m_flAttenuation, SND_CHANGE_PITCH | SND_CHANGE_VOL, pitch );
}

//
// SpinUp - accelerates a non-moving func_rotating up to it's speed
//
void CFuncRotating::SpinUp()
{
	Vector	vecAVel;//rotational velocity

	pev->nextthink = pev->ltime + 0.1f;
	pev->avelocity = pev->avelocity + ( pev->movedir * ( pev->speed * m_flFanFriction ) );

	vecAVel = pev->avelocity;// cache entity's rotational velocity

	// if we've met or exceeded target speed, set target speed and stop thinking
	if( fabs( vecAVel.x ) >= fabs( pev->movedir.x * pev->speed ) &&
		fabs( vecAVel.y ) >= fabs( pev->movedir.y * pev->speed ) &&
		fabs( vecAVel.z ) >= fabs( pev->movedir.z * pev->speed ) )
	{
		pev->avelocity = pev->movedir * pev->speed;// set speed in case we overshot
		EMIT_SOUND_DYN( ENT( pev ), CHAN_STATIC, STRING( pev->noiseRunning ), 
			m_flVolume, m_flAttenuation, SND_CHANGE_PITCH | SND_CHANGE_VOL, FANPITCHMAX );

		SetThink( &CFuncRotating::Rotate );
		Rotate();
	} 
	else
	{
		RampPitchVol( true );
	}
}

//
// SpinDown - decelerates a moving func_rotating to a standstill.
//
void CFuncRotating::SpinDown()
{
	Vector vecAVel;//rotational velocity
	float vecdir;

	pev->nextthink = pev->ltime + 0.1f;

	pev->avelocity = pev->avelocity - ( pev->movedir * ( pev->speed * m_flFanFriction ) );//spin down slower than spinup

	vecAVel = pev->avelocity;// cache entity's rotational velocity

	if( pev->movedir.x != 0.0f )
		vecdir = pev->movedir.x;
	else if( pev->movedir.y != 0.0f )
		vecdir = pev->movedir.y;
	else
		vecdir = pev->movedir.z;

	// if we've met or exceeded target speed, set target speed and stop thinking
	// (note: must check for movedir > 0 or < 0)
	if( ( ( vecdir > 0.0f ) && ( vecAVel.x <= 0.0f && vecAVel.y <= 0.0f && vecAVel.z <= 0.0f ) ) || 
		( ( vecdir < 0.0f ) && ( vecAVel.x >= 0.0f && vecAVel.y >= 0.0f && vecAVel.z >= 0.0f ) ) )
	{
		pev->avelocity = g_vecZero;// set speed in case we overshot

		// stop sound, we're done
		EMIT_SOUND_DYN( ENT( pev ), CHAN_STATIC, STRING( pev->noiseRunning /* Stop */ ),
				0, 0, SND_STOP, (int)m_pitch );

		SetThink( &CFuncRotating::Rotate );
		Rotate();
	} 
	else
	{
		RampPitchVol( false );
	}
}

void CFuncRotating::Rotate()
{
	pev->nextthink = pev->ltime + 10.0f;
}

//=========================================================
// Rotating Use - when a rotating brush is triggered
//=========================================================
void CFuncRotating::RotatingUse( CBaseEntity *pActivator, CBaseEntity *pCaller, USE_TYPE useType, float value )
{
	// is this a brush that should accelerate and decelerate when turned on/off (fan)?
	if( FBitSet ( pev->spawnflags, SF_BRUSH_ACCDCC ) )
	{
		// fan is spinning, so stop it.
		if( pev->avelocity != g_vecZero )
		{
			SetThink( &CFuncRotating::SpinDown );
			//EMIT_SOUND_DYN( ENT( pev ), CHAN_WEAPON, STRING( pev->noiseStop ),
			//	m_flVolume, m_flAttenuation, 0, m_pitch );

			pev->nextthink = pev->ltime + 0.1f;
		}
		else// fan is not moving, so start it
		{
			SetThink( &CFuncRotating::SpinUp );
			EMIT_SOUND_DYN( ENT( pev ), CHAN_STATIC, STRING( pev->noiseRunning ),
				0.01f, m_flAttenuation, 0, FANPITCHMIN );

			pev->nextthink = pev->ltime + 0.1f;
		}
	}
	else if( !FBitSet( pev->spawnflags, SF_BRUSH_ACCDCC ) )//this is a normal start/stop brush.
	{
		if( pev->avelocity != g_vecZero )
		{
			// play stopping sound here
			SetThink( &CFuncRotating::SpinDown );

			// EMIT_SOUND_DYN( ENT( pev ), CHAN_WEAPON, STRING( pev->noiseStop ),
			//	m_flVolume, m_flAttenuation, 0, m_pitch );

			pev->nextthink = pev->ltime + 0.1f;
			// pev->avelocity = g_vecZero;
		}
		else
		{
			EMIT_SOUND_DYN( ENT( pev ), CHAN_STATIC, STRING( pev->noiseRunning ),
				m_flVolume, m_flAttenuation, 0, FANPITCHMAX );
			pev->avelocity = pev->movedir * pev->speed;

			SetThink( &CFuncRotating::Rotate );
			Rotate();
		}
	}
}

//
// RotatingBlocked - An entity has blocked the brush
//
void CFuncRotating::Blocked( CBaseEntity *pOther )
{
	if (pOther->pev->takedamage)
	{
		if (!FBitSet(pev->spawnflags, SF_ROTATING_LIMIG_BLOCKING_DAMAGE))
		{
			pOther->TakeDamage( pev, pev, DamageInfo(pev->dmg, DMG_CRUSH) );
			return;
		}

		int entindex = pOther->entindex();
		int i;
		for (i=0; i<ROTATING_BLOCKING_ENT_NUM; ++i)
		{
			if (m_blockingEntities[i] == entindex)
			{
				if (m_blockingTimes[i] <= gpGlobals->time - 0.1f)
				{
					pOther->TakeDamage( pev, pev, DamageInfo(pev->dmg, DMG_CRUSH) );
					m_blockingTimes[i] = gpGlobals->time;
				}
				return;
			}
		}
		int j = 0;
		float blockTime = m_blockingTimes[0];
		for (i=1; i<ROTATING_BLOCKING_ENT_NUM; ++i)
		{
			if (m_blockingTimes[i] < blockTime)
			{
				blockTime = m_blockingTimes[i];
				j = i;
			}
		}
		m_blockingTimes[j] = gpGlobals->time;
		m_blockingEntities[j] = entindex;

		pOther->TakeDamage( pev, pev, DamageInfo(pev->dmg, DMG_CRUSH) );
	}
}
//#endif

#define	SF_PENDULUM_BOTHWAYS 256

class CPendulum : public CBaseEntity
{
public:
	void Spawn() override;
	void KeyValue( KeyValueData *pkvd ) override;
	void EXPORT Swing();
	void EXPORT PendulumUse( CBaseEntity *pActivator, CBaseEntity *pCaller, USE_TYPE useType, float value );
	void EXPORT Stop();
	void Touch( CBaseEntity *pOther ) override;
	void EXPORT RopeTouch( CBaseEntity *pOther );// this touch func makes the pendulum a rope
	int ObjectCaps() override { return CBaseEntity :: ObjectCaps() & ~FCAP_ACROSS_TRANSITION; }
	int Save( CSave &save ) override;
	int Restore( CRestore &restore ) override;
	void Blocked( CBaseEntity *pOther ) override;

	static TYPEDESCRIPTION m_SaveData[];

	float m_accel;			// Acceleration
	float m_distance;
	float m_time;
	float m_damp;
	float m_maxSpeed;
	float m_dampSpeed;
	Vector m_center;
	Vector m_start;
};

LINK_ENTITY_TO_CLASS( func_pendulum, CPendulum )

TYPEDESCRIPTION	CPendulum::m_SaveData[] =
{
	DEFINE_FIELD( CPendulum, m_accel, FIELD_FLOAT ),
	DEFINE_FIELD( CPendulum, m_distance, FIELD_FLOAT ),
	DEFINE_FIELD( CPendulum, m_time, FIELD_TIME ),
	DEFINE_FIELD( CPendulum, m_damp, FIELD_FLOAT ),
	DEFINE_FIELD( CPendulum, m_maxSpeed, FIELD_FLOAT ),
	DEFINE_FIELD( CPendulum, m_dampSpeed, FIELD_FLOAT ),
	DEFINE_FIELD( CPendulum, m_center, FIELD_VECTOR ),
	DEFINE_FIELD( CPendulum, m_start, FIELD_VECTOR ),
};

IMPLEMENT_SAVERESTORE( CPendulum, CBaseEntity )

void CPendulum::KeyValue( KeyValueData *pkvd )
{
	if( FStrEq( pkvd->szKeyName, "distance" ) )
	{
		m_distance = atof( pkvd->szValue );
		pkvd->fHandled = true;
	}
	else if( FStrEq( pkvd->szKeyName, "damp" ) )
	{
		m_damp = atof( pkvd->szValue ) * 0.001f;
		pkvd->fHandled = true;
	}
	else 
		CBaseEntity::KeyValue( pkvd );
}

void CPendulum::Spawn()
{
	// set the axis of rotation
	CBaseToggle::AxisDir( pev );

	if( FBitSet( pev->spawnflags, SF_DOOR_PASSABLE ) )
		pev->solid = SOLID_NOT;
	else
		pev->solid = SOLID_BSP;
	pev->movetype = MOVETYPE_PUSH;
	UTIL_SetOrigin( pev, pev->origin );
	SET_MODEL( ENT( pev ), STRING( pev->model ) );

	if( m_distance == 0 )
		return;

	if( pev->speed == 0.0f )
		pev->speed = 100.0f;

	const float multiplier = (FBitSet(pev->spawnflags, SF_PENDULUM_BOTHWAYS)) ? 1.0f : 2.0f;
	m_accel = ( pev->speed * pev->speed ) / ( multiplier * fabs( m_distance ) );	// Calculate constant acceleration from speed and distance
	m_maxSpeed = pev->speed;
	m_start = pev->angles;
	if (FBitSet(pev->spawnflags, SF_PENDULUM_BOTHWAYS))
		m_center = m_start;
	else
		m_center = pev->angles + ( m_distance * 0.5f ) * pev->movedir;

	if( FBitSet( pev->spawnflags, SF_BRUSH_ROTATE_INSTANT ) )
	{	
		SetThink( &CBaseEntity::SUB_CallUseToggle );
		pev->nextthink = gpGlobals->time + 0.1f;
	}
	pev->speed = 0;
	SetUse( &CPendulum::PendulumUse );

	if( FBitSet( pev->spawnflags, SF_PENDULUM_SWING ) )
	{
		SetTouch( &CPendulum::RopeTouch );
	}
}

void CPendulum::PendulumUse( CBaseEntity *pActivator, CBaseEntity *pCaller, USE_TYPE useType, float value )
{
	if( pev->speed )		// Pendulum is moving, stop it and auto-return if necessary
	{
		if( FBitSet( pev->spawnflags, SF_PENDULUM_AUTO_RETURN ) )
		{		
			float delta;

			delta = CBaseToggle::AxisDelta( pev->spawnflags, pev->angles, m_start );

			pev->avelocity = m_maxSpeed * pev->movedir;
			pev->nextthink = pev->ltime + ( delta / m_maxSpeed );
			SetThink( &CPendulum::Stop );
		}
		else
		{
			pev->speed = 0.0f;		// Dead stop
			SetThink( NULL );
			pev->avelocity = g_vecZero;
		}
	}
	else
	{
		pev->nextthink = pev->ltime + 0.1f;		// Start the pendulum moving
		m_time = gpGlobals->time;		// Save time to calculate dt
		SetThink( &CPendulum::Swing );
		m_dampSpeed = m_maxSpeed;
	}
}

void CPendulum::Stop()
{
	pev->angles = m_start;
	pev->speed = 0.0f;
	SetThink( NULL );
	pev->avelocity = g_vecZero;
}

void CPendulum::Blocked( CBaseEntity *pOther )
{
	m_time = gpGlobals->time;
}

void CPendulum::Swing()
{
	float delta, dt;

	delta = CBaseToggle::AxisDelta( pev->spawnflags, pev->angles, m_center );
	dt = gpGlobals->time - m_time;	// How much time has passed?
	m_time = gpGlobals->time;		// Remember the last time called

	if( delta > 0.0f && m_accel > 0.0f )
		pev->speed -= m_accel * dt;	// Integrate velocity
	else 
		pev->speed += m_accel * dt;

	if( pev->speed > m_maxSpeed )
		pev->speed = m_maxSpeed;
	else if( pev->speed < -m_maxSpeed )
		pev->speed = -m_maxSpeed;
	// scale the destdelta vector by the time spent traveling to get velocity
	pev->avelocity = pev->speed * pev->movedir;

	// Call this again
	pev->nextthink = pev->ltime + 0.1f;

	if( m_damp )
	{
		m_dampSpeed -= m_damp * m_dampSpeed * dt;
		if( m_dampSpeed < 30.0f )
		{
			pev->angles = m_center;
			pev->speed = 0;
			SetThink( NULL );
			pev->avelocity = g_vecZero;
		}
		else if( pev->speed > m_dampSpeed )
			pev->speed = m_dampSpeed;
		else if( pev->speed < -m_dampSpeed )
			pev->speed = -m_dampSpeed;
	}
}

void CPendulum::Touch( CBaseEntity *pOther )
{
	entvars_t *pevOther = pOther->pev;

	if( pev->dmg <= 0 )
		return;

	// we can't hurt this thing, so we're not concerned with it
	if( !pevOther->takedamage )
		return;

	// calculate damage based on rotation speed
	float damage = pev->dmg * pev->speed * 0.01f;

	if( damage < 0 )
		damage = -damage;

	pOther->TakeDamage( pev, pev, DamageInfo(damage, DMG_CRUSH) );

	pevOther->velocity = ( pevOther->origin - VecBModelOrigin( pev ) ).Normalize() * damage;
}

void CPendulum::RopeTouch( CBaseEntity *pOther )
{
	entvars_t *pevOther = pOther->pev;

	if( !pOther->IsPlayer() )
	{
		// not a player!
		ALERT( at_console, "Not a client\n" );
		return;
	}

	if( ENT( pevOther ) == pev->enemy )
	{
		// this player already on the rope.
		return;
	}

	pev->enemy = pOther->edict();
	pevOther->velocity = g_vecZero;
	pevOther->movetype = MOVETYPE_NONE;
}
